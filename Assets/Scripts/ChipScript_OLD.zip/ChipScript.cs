﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChipScript : MonoBehaviour 
{
	public Button btnRoll;
	public Text txtBet;
	public Text txtWin;
	public Text txtType;
	public Text txtRolled;
	public Text txtBetNumbers;

	int rolled_number = 1;
	int no;                   // privremeno, za prikaz odabranih brojeva
	decimal bet = 10;
	decimal win = 0;
	string win_type = "";

	List<GameObject> currentCollisions = new List<GameObject>();

	void Start () 
	{
		Button btn = btnRoll.GetComponent<Button>();
		btnRoll.onClick.AddListener( btnRollClick );

		UpdateUI();
	}
	

	void Update () 
	{
		
	}

	/*
	void OnTriggerEnter2D(Collider2D other)
	{
		print( other.name );
	}
	*/
	void btnRollClick()
	{
		win = 0;
		txtBetNumbers.text = "Bet: ";

		rolled_number = GameManager.gm.GetRandomNumber();

		// ispisi kontakte
		for ( int i = 0; i< currentCollisions.Count; i++ )
		{
			//print( currentCollisions[i].name );
		}

		// proveri tip dobitka ( BET NAME )
	
		if ( currentCollisions.Count == 1 )
		{
			win_type = "Straight Up";
		}

		if ( currentCollisions.Count == 2 )
		{
			win_type = "Split";
		}
		if ( currentCollisions.Count == 3 )
		{
			win_type = "Street";
		}
		if ( currentCollisions.Count == 4 )
		{
			win_type = "Corner";
		}
		print( "-----------------------------------" );

		/* proveri da li smo nesto dobili */
		for ( int i = 0; i< currentCollisions.Count; i++ )
		{
			/* skloni nazive */
			string temp_string;
			temp_string = currentCollisions[i].name.Replace( "FIELD_", "" );
			temp_string = currentCollisions[i].name.Replace( "F_", "" );
			no = int.Parse( temp_string );

			txtBetNumbers.text += no.ToString() + " ";

			// PROVERI DOBITAK ZA OBICNE BROJEVE
			if( no == rolled_number )
			{
				if( currentCollisions.Count == 1 )
				{
					win = bet * 35;
				}
				else
				if( currentCollisions.Count == 2 )
				{
					win = bet * 17;
				}
				else
				if( currentCollisions.Count == 3 )
				{
					win = bet * 11;
				}
				else
				if( currentCollisions.Count == 4 )
				{
					win = bet * 8;
				}
				else
				{
					win = 0;
				}
				//GameManager.gm.TotalWin += win;
			}
				
		}
			
		// AKO JE ODABRAN SAMO JEDAN BROJ, PROVERI I OSTALE DOBITKE
		if( currentCollisions.Count == 1 )
		{
			if( isNumberBlack( no ) )
				print( "BLACK" );
			else
				print( "RED" );
		}

		UpdateAfterRoll();
		//print( GameManager.gm.TotalWin );
	}

	// crno   - par   - true
	// crveno - nepar - false
	bool isNumberBlack ( int n )
	{
		bool res = true;

		if( n <= 10 )
		{
			if( n % 2 == 0 )
				return true;
			else
				return false;
		}
		if( n >= 11 && n<= 19)
		{
			if( n % 2 == 0 )
				return false;
			else
				return true;
		}
		if( n >= 20 && n <= 28 )
		{
			if( n % 2 == 0 )
				return true;
			else
				return false;			
		}
		if( n >= 29 && n <= 36 )
		{
			if( n % 2 == 0 )
				return false;
			else
				return true;			
		}
		return false;
	}
		
	void OnTriggerEnter2D (Collider2D other)
	{
		currentCollisions.Add( other.gameObject );
	}
		
	void OnTriggerExit2D (Collider2D other)
	{
		currentCollisions.Remove( other.gameObject );
	}

	void UpdateUI()
	{
		txtBet.text = "Bet: " + bet.ToString();
		txtWin.text = "Win: ";
		txtType.text = "Bet name: ";
		txtRolled.text = "Roll: ";			
	}

	void UpdateAfterRoll()
	{
		txtBet.text = "Bet: " + bet.ToString();
		txtWin.text = "Win: " + win.ToString();
		txtType.text = "Bet name: " + win_type.ToString();
		txtRolled.text = "Roll: " + rolled_number.ToString();
		//txtRolled.text = "Roll: 1";
	}
}
